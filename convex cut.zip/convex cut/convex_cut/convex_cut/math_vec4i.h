class vec4i
{
public:
	inline vec4i(){}
	inline vec4i(const vec4i& that)
	{
		for (int n = 0; n < 4; n++)
			data[n] = that.data[n];
	}
	explicit inline vec4i(const int& s)
	{
		for (int n = 0; n < 4; n++)
		{
			data[n] = s;
		}
	}

	inline vec4i&	operator=(const vec4i& that)
	{
		for (int n = 0; n < 4; n++)
			data[n] = that.data[n];
		return *this;
	}
	inline vec4i	operator-() const
	{
		vec4i result;
		for (int n = 0; n < 4; n++)
			result.data[n] = -data[n];
		return result;
	}
	inline vec4i	operator-(const vec4i& that) const
	{
		vec4i result;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] - that.data[n];
		return result;
	}
	inline vec4i	operator+() const
	{
		return *this;
	}
	inline vec4i	operator+(const vec4i& that) const
	{
		vec4i result;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] + that.data[n];
		return result;
	}
	inline vec4i	operator*(const vec4i& that) const
	{
		vec4i result;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] * that.data[n];
		return result;
	}
	inline vec4i	operator*(const int& that) const
	{
		vec4i result;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] * that;
		return result;
	}
	inline vec4i	operator/(const vec4i& that) const
	{
		vec4i result;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] / that.data[n];
		return result;
	}
	inline vec4i	operator/(const int& that) const
	{
		vec4i result;
		int _l = 1.0f / that;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] * _l;
		return result;
	}
	inline vec4i&	operator+=(const vec4i& that)
	{
		return (*this = *this + that);//����������ֵ,��Ҫ�Ⱥ�
	}
	inline vec4i&	operator-=(const vec4i& that)
	{
		return (*this = *this - that);
	}
	inline vec4i&	operator*=(const vec4i& that)
	{
		return (*this = *this * that);
	}
	inline vec4i&	operator*=(const int& that)
	{
		return (*this = *this * that);
	}
	inline vec4i&	operator/=(const vec4i& that)
	{
		return (*this = *this / that);
	}
	inline vec4i&	operator/=(const int& that)
	{
		return (*this = *this / that);
	}
	inline bool		operator==(const vec4i& that)
	{
		for(int n = 0; n < 4; n++){
			if(data[n] != that.data[n])
				return false;
		}
		return true;
	}
	inline bool		operator!=(const vec4i& that)
	{
		for(int n = 0; n < 4; n++){
			if(data[n] != that.data[n])
				return true;
		}
		return false;
	}
	//��дconst,���޷�����const����
	//ֻдconst,���ܷ���ֵ�ı�������Ϊconst,�����޸�
	inline int&		operator[](int n) {return data[n];}
	inline const int& operator[](int n) const {return data[n];}
	//ת���
	inline		operator		int* ()		{return &data[0];}
	inline		operator const	int* () const {return &data[0];}
	int data[4];

	inline vec4i(const int& x, const int& y, const int& z, const int& w)
	{
		data[0] = x;
		data[1] = y;
		data[2] = z;
		data[3] = w;
	}
};
class mat2
{
public:
	inline mat2(){}
	inline mat2(const mat2& that)
	{
		int i, j;
		for(i = 0; i < 2; i++)
		for(j = 0; j < 2; j++)
			data[i][j] = that.data[i][j];
	}
	explicit inline mat2(const float that)
	{
		int i, j;
		for(i = 0; i < 2; i++)
		for(j = 0; j < 2; j++)
			data[i][j] = that;
	}
	inline mat2&	operator=(const mat2& that)
	{
		int i, j;
		for(i = 0; i < 2; i++)
		for(j = 0; j < 2; j++)
			data[i][j] = that.data[i][j];

		return *this;
	}
	inline mat2		operator+(const mat2& that) const
	{
		mat2 result;
		int i, j;
		for(i = 0; i < 2; i++)
		for(j = 0; j < 2; j++)
			result.data[i][j] = data[i][j] + that.data[i][j];

		return result;
	}
	inline mat2		operator-(const mat2& that) const
	{
		mat2 result;
		int i, j;
		for(i = 0; i < 2; i++)
		for(j = 0; j < 2; j++)
			result.data[i][j] = data[i][j] - that.data[i][j];
		
		return result;
	}
	inline mat2		operator*(const float& that) const
	{
		mat2 result;
		int i, j;
		for(i = 0; i < 2; i++)
		for(j = 0; j < 2; j++)
			result.data[i][j] = data[i][j] * that;

		return result;
	}
	//δ���� �о��� 1��*2��
	inline mat2		operator*(const mat2& that) const
	{
		mat2 result(0);
		int i, j, n;
		for(i = 0; i < 2; i++)
		for(j = 0; j < 2; j++)
		for(n = 0; n < 2; n++)
			result.data[i][j] += data[i][n] * that.data[n][j];

		return result;
	}
	inline mat2		operator/(const float& that) const
	{
		mat2 result;
		int i, j;
		float _l = 1.0f / that;
		for(i = 0; i < 2; i++)
		for(j = 0; j < 2; j++)
			result.data[i][j] = data[i][j] * _l;

		return result;
	}
	inline mat2&	operator+=(const mat2& that)
	{
		return (*this = *this + that);//��������ʱ���� return *this,���򲻸ı�ʵ��
	}
	inline mat2&	operator-=(const mat2& that)
	{
		return (*this = *this - that);
	}
	inline mat2&	operator*=(const float& that)
	{
		return (*this = *this * that);
	}
	inline mat2&	operator*=(const mat2& that)
	{
		return (*this = *this * that);
	}
	inline mat2&	operator/=(const float& that)
	{
		return (*this = *this / that);
	}
	inline bool		operator==(const mat2& that)
	{
		int i, j;
		for(i = 0; i < 2; i++)
		for(j = 0; j < 2; j++)
			if(data[i][j] != that.data[i][j])
				return false;

		return true;
	}
	inline bool		operator!=(const mat2& that)
	{
		int i, j;
		for(i = 0; i < 2; i++)
		for(j = 0; j < 2; j++)
			if(data[i][j] != that.data[i][j])
				return true;

		return false;
	}

	inline			vec2& operator[](int n)			{ return data[n]; }
	inline const	vec2& operator[](int n) const	{ return data[n]; }
	inline		operator		float* ()		{return &data[0][0];}
	inline		operator const	float* () const {return &data[0][0];}
	vec2 data[2];

	inline mat2(
		const float& m00, const float& m01,
		const float& m10, const float& m11)
	{
		data[0][0] = m00;	data[0][1] = m01;
		data[1][0] = m10;	data[1][1] = m11;
	}
};
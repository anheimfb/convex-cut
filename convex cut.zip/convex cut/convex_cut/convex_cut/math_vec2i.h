class vec2i
{
public:
	inline vec2i(){}
	inline vec2i(const vec2i& that)
	{
		for (int n = 0; n < 2; n++)
			data[n] = that.data[n];
	}
	explicit inline vec2i(const int& s)
	{
		for (int n = 0; n < 2; n++)
		{
			data[n] = s;
		}
	}

	inline vec2i&	operator=(const vec2i& that)
	{
		for (int n = 0; n < 2; n++)
			data[n] = that.data[n];
		return *this;
	}
	inline vec2i	operator-() const
	{
		vec2i result;
		for (int n = 0; n < 2; n++)
			result.data[n] = -data[n];
		return result;
	}
	inline vec2i	operator-(const vec2i& that) const
	{
		vec2i result;
		for (int n = 0; n < 2; n++)
			result.data[n] = data[n] - that.data[n];
		return result;
	}
	inline vec2i	operator+() const
	{
		return *this;
	}
	inline vec2i	operator+(const vec2i& that) const
	{
		vec2i result;
		for (int n = 0; n < 2; n++)
			result.data[n] = data[n] + that.data[n];
		return result;
	}
	inline vec2i	operator*(const vec2i& that) const
	{
		vec2i result;
		for (int n = 0; n < 2; n++)
			result.data[n] = data[n] * that.data[n];
		return result;
	}
	inline vec2i	operator*(const int& that) const
	{
		vec2i result;
		for (int n = 0; n < 2; n++)
			result.data[n] = data[n] * that;
		return result;
	}
	inline vec2i	operator/(const vec2i& that) const
	{
		vec2i result;
		for (int n = 0; n < 2; n++)
			result.data[n] = data[n] / that.data[n];
		return result;
	}
	inline vec2i	operator/(const int& that) const
	{
		vec2i result;
		int _l = 1.0f / that;
		for (int n = 0; n < 2; n++)
			result.data[n] = data[n] * _l;
		return result;
	}
	inline vec2i&	operator+=(const vec2i& that)
	{
		return (*this = *this + that);//����������ֵ,��Ҫ�Ⱥ�
	}
	inline vec2i&	operator-=(const vec2i& that)
	{
		return (*this = *this - that);
	}
	inline vec2i&	operator*=(const vec2i& that)
	{
		return (*this = *this * that);
	}
	inline vec2i&	operator*=(const int& that)
	{
		return (*this = *this * that);
	}
	inline vec2i&	operator/=(const vec2i& that)
	{
		return (*this = *this / that);
	}
	inline vec2i&	operator/=(const int& that)
	{
		return (*this = *this / that);
	}
	inline bool		operator==(const vec2i& that)
	{
		for(int n = 0; n < 2; n++){
			if(data[n] != that.data[n])
				return false;
		}
		return true;
	}
	inline bool		operator!=(const vec2i& that)
	{
		for(int n = 0; n < 2; n++){
			if(data[n] != that.data[n])
				return true;
		}
		return false;
	}
	//��дconst,���޷�����const����
	//ֻдconst,���ܷ���ֵ�ı�������Ϊconst,�����޸�
	inline int&		operator[](int n)		{return data[n];}
	inline const int& operator[](int n) const {return data[n];}
	//ת���
	inline		operator		int* ()		{return &data[0];}
	inline		operator const	int* () const {return &data[0];}
	int data[2];

	inline vec2i(const int& x, const int& y)
	{
		data[0] = x;
		data[1] = y;
	}
};
class mat4
{
public:
	inline mat4(){}
	inline mat4(const mat4& that)
	{
		int i, j;
		for(i = 0; i < 4; i++)
		for(j = 0; j < 4; j++)
			data[i][j] = that.data[i][j];
	}
	explicit inline mat4(const float that)
	{
		int i, j;
		for(i = 0; i < 4; i++)
		for(j = 0; j < 4; j++)
			data[i][j] = that;
	}
	inline mat4&	operator=(const mat4& that)
	{
		int i, j;
		for(i = 0; i < 4; i++)
		for(j = 0; j < 4; j++)
			data[i][j] = that.data[i][j];

		return *this;
	}
	inline mat4		operator+(const mat4& that) const
	{
		mat4 result;
		int i, j;
		for(i = 0; i < 4; i++)
		for(j = 0; j < 4; j++)
			result.data[i][j] = data[i][j] + that.data[i][j];

		return result;
	}
	inline mat4		operator-(const mat4& that) const
	{
		mat4 result;
		int i, j;
		for(i = 0; i < 4; i++)
		for(j = 0; j < 4; j++)
			result.data[i][j] = data[i][j] - that.data[i][j];
		
		return result;
	}
	inline mat4		operator*(const float& that) const
	{
		mat4 result;
		int i, j;
		for(i = 0; i < 4; i++)
		for(j = 0; j < 4; j++)
			result.data[i][j] = data[i][j] * that;

		return result;
	}
	//δ���� �о��� 1��*2��
	inline mat4		operator*(const mat4& that) const
	{
		mat4 result(0);
		int i, j, n;
		for(i = 0; i < 4; i++)
		for(j = 0; j < 4; j++)
		for(n = 0; n < 4; n++)
			result.data[i][j] += data[i][n] * that.data[n][j];

		return result;
	}
	inline mat4		operator/(const float& that) const
	{
		mat4 result;
		int i, j;
		float _l = 1.0f / that;
		for(i = 0; i < 4; i++)
		for(j = 0; j < 4; j++)
			result.data[i][j] = data[i][j] * _l;

		return result;
	}
	inline mat4&	operator+=(const mat4& that)
	{
		return (*this = *this + that);//��������ʱ���� return *this,���򲻸ı�ʵ��
	}
	inline mat4&	operator-=(const mat4& that)
	{
		return (*this = *this - that);
	}
	inline mat4&	operator*=(const float& that)
	{
		return (*this = *this * that);
	}
	inline mat4&	operator*=(const mat4& that)
	{
		return (*this = *this * that);
	}
	inline mat4&	operator/=(const float& that)
	{
		return (*this = *this / that);
	}
	inline bool		operator==(const mat4& that)
	{
		int i, j;
		for(i = 0; i < 4; i++)
		for(j = 0; j < 4; j++)
			if(data[i][j] != that.data[i][j])
				return false;

		return true;
	}
	inline bool		operator!=(const mat4& that)
	{
		int i, j;
		for(i = 0; i < 4; i++)
		for(j = 0; j < 4; j++)
			if(data[i][j] != that.data[i][j])
				return true;

		return false;
	}

	inline			vec4& operator[](int n)			{ return data[n]; }
	inline const	vec4& operator[](int n) const	{ return data[n]; }
	inline		operator		float* ()		{return &data[0][0];}
	inline		operator const	float* () const {return &data[0][0];}

	vec4 data[4];

	inline mat4(
		const float& m00, const float& m01, const float& m02, const float& m03,
		const float& m10, const float& m11, const float& m12, const float& m13,
		const float& m20, const float& m21, const float& m22, const float& m23,
		const float& m30, const float& m31, const float& m32, const float& m33)
	{
		data[0][0] = m00;	data[0][1] = m01;	data[0][2] = m02;	data[0][3] = m03;
		data[1][0] = m10;	data[1][1] = m11;	data[1][2] = m12;	data[1][3] = m13;
		data[2][0] = m20;	data[2][1] = m21;	data[2][2] = m22;	data[2][3] = m23;
		data[3][0] = m30;	data[3][1] = m31;	data[3][2] = m32;	data[3][3] = m33;
	}
};
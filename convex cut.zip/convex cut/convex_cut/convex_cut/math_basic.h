#define PIx2	6.2831853071796
#define PI		3.14159265358979323846
#define PI_2    1.57079632679489661923
#define PI_3    1.0471975511965977461542144610932
#define PI_4    0.785398163397448309616
#define PI_6	0.52359877559829887307710723054658
#define SQRT2	1.41421356237309504880
#define SQRT2_2	0.7071067811865475244008443621048490
#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif
//ȡ����
template<typename T>
static inline int		sign(T y)
{    
	if(y > 0)
		return 1;
	if(y == 0)
		return 0;
	else
		return -1;
}
//ȡ��
template<typename T>
static inline T			rem(T a, T b)
{
	int c = int(a / b);//��0��������
	return (a - c * b);
}
//ȡģ
template< typename T >
static inline T			mod(T a, T b)
{
	int c = floor(a/b);//�����������
	return (a - c * b);
}
//�Լ�ʵ��floor
static inline float		floor1(float a)
{
	int r = a;

	if (a < 0) 
		--r;

	return (float) r;
}
//�Ƕ�ת����
static inline float		radians(float angle)
{
	return angle * 0.017453292519943295769236;//float(PI / 180.0)
}
////srand(int)//rand=======================================================
//rand a~b һ��Ҫ b > a,�����������
static inline int		rand_in(int a, int b)//�������Ը��� ȡ�໹������,����һ��Ҫ b > a,�����������
{
	assert(b >= a);
	int r = rand();
	int r_ = r % (b - a + 1);
	return r_ + a;
}
//rand 0~a
static inline int		rand_in(int a)
{
	return rand() % (a + 1);
}
//rand a + 0~n
static inline int		rand_in_add(int a, int n)
{
	return a + rand() % (n + 1);
}
//rand 0~1
static inline double	rand_in_one()//0 < m%n < n
{
	return rand() / double(RAND_MAX);
}
//bullet������������
//extern unsigned long m_btSeed2;
//static inline float		btRand2()
//{
//	m_btSeed2 = (1664525L * m_btSeed2 + 1013904223L) & 0xffffffff;
//	return m_btSeed2;
//}
//clamp
static inline float		clamp(float fValue, float fMin, float fMax)
{
    return    fValue > fMax ? fMax : (fValue < fMin ? fMin : fValue); 
}
//ƽ��
static inline float		sqr(float a)
{
    return  a * a;
}
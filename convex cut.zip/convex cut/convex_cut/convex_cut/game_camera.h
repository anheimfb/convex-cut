//�Ľ���Ϊ��ӭ�����νṹ Ҳ�����ԶԳ�Ա������Щ���⴦���� local_p, local_r, local_transform, global_transform
class CCamera
{
public:
	enum Type
	{
		eOrtho = 0,
		ePerspective = 1
	};

	CCamera()
	{
		m_rotation = vec3Zero;
		m_position = vec3(0, 0, -10);

		m_proj_type = ePerspective;
		m_proj_width = 640;
		m_proj_height = 480;
		
		m_vx = 0;
		m_vy = 0;
		m_vw = 0;
		m_vh = 0;

		m_move_speed = 1;
		m_rotate_speed= 0.01;
	}

	void SetProjSize(float w, float h)
	{
		m_proj_width = w;
		m_proj_height = h;
	}
	void SetProjPerspective()
	{
		m_proj_type = ePerspective;
	}
	void SetProjOrtho()
	{
		m_proj_type = eOrtho;
	}
	void SetViewport(float x, float y, float w, float h)
	{
		m_vx = x;
		m_vy = y;
		m_vw = w;
		m_vh = h;
	}
	vec2 GetMouseProjPos()
	{
		double mouse_x;
		double mouse_y;
		Input::MouseGetPos(mouse_x, mouse_y);
		float s_x = m_vx;
		float s_y = m_vy; 
		float s_w = m_vw; 
		float s_h = m_vh;
		float c_x = m_position[0];
		float c_y = m_position[1];
		float c_w = m_proj_width;
		float c_h = m_proj_height;
		float x = (mouse_x - s_x - s_w * 0.5) * c_w / s_w + c_x;
		float y = -(mouse_y - s_y - s_h * 0.5) * c_h / s_h + c_y;
		return vec2(x, y);
	}
	vec2 GetScreenCenter()
	{
		return vec2(m_vx + m_vw * 0.5, m_vy + m_vh * 0.5);
	}
	vec2 GetMouseOff()
	{
		double mouse_x;
		double mouse_y;
		Input::MouseGetPos(mouse_x, mouse_y);
		vec2 center = this->GetScreenCenter();

		vec2 off(0);
		//���⸡�����
		off[0] = mouse_x - int(center[0]);
		off[1] = mouse_y - int(center[1]);
		return off;
	}

	void GetMouseRay(vec3& pos, vec3& dir)
	{
		vec2 off = this->GetMouseOff();
		if(m_proj_type == CCamera::eOrtho)
		{
			off[0] *= m_proj_width / m_vw;
			off[1] *= -m_proj_height / m_vh;

			pos = m_position + ToVec3(off, 0);

			dir = vec3Z * rotateXYZ(m_rotation);
		}
		else
		{
			float  tan_top = tan(0.5f * PI_4);//perspective��������
			float  tan_right = tan_top * m_proj_width / m_proj_height;

			off /= vec2(m_proj_width * 0.5, m_proj_height * 0.5);

			pos = m_position;		

			dir = vec3(
				1 * tan_right * off[0],
				1 * tan_top * (-off[1]),//��Ļy�볡��y�෴
				1);

			dir = normalize(dir);
			dir = dir* rotateXYZ(m_rotation);
		}
	}
	vec3 GetMouseRayPoint(vec3 normal = vec3Y, float depth = 0)
	{
		vec3 point;
		vec3 pos;
		vec3 dir;
		this->GetMouseRay(pos, dir);

		//(pos + dir * d)normal = depth, �� ���߳���d 
		//��:d = (depth - pos * normal) /(dir * normal)
		float d;
		float dev = dot(dir, normal);
		if(abs(dev) > 0.0001)
		{
			d = (depth - dot(pos, normal)) / dev;
		}
		else
		{
			d = 100;//dir��normalƽ��,�Լ�����һ������
		}

		point = pos + dir * d;

		return point;
	}
	mat4 GetProj()
	{
		float w = m_proj_width * 0.5;
		float h = m_proj_height * 0.5;

		if(w == 0)w = 1;
		if(h == 0)h = 1;

		//ortho
		if(m_proj_type == eOrtho)
		{
			return ortho(-w, w, -h, h, 0.1, 3000);//ortho(-g_window_width / 2, g_window_width / 2, -g_window_height / 2, g_window_height / 2, 0.1, 3000);//
		}
		//perspective
		else
		{
			return perspective(PI_4, (float)w / h, 0.1, 3000);
		}
	}
	mat4 GetView()
	{
		mat3 r = rotateXYZ(m_rotation);
		mat3 inv_r = transpose(r);
		mat4 view = translate(-m_position) * ToMat4(inv_r, vec3Zero);
		//view = lookat(m_position, vec3Z, vec3Y, vec3X);
		return view;
	}
	mat4 GetViewRot()
	{
		mat3 r = rotateXYZ(m_rotation);
		mat3 inv_r = transpose(r);
		mat4 view = ToMat4(inv_r, vec3Zero);
		return view;
	}
	vec3 GetLook()
	{
		return vec3Z * rotateXYZ(m_rotation);
	}
	mat3 GetRotMat3()
	{
		return rotateXYZ(m_rotation);
	}
	mat4 GetMat4()
	{
		return ToMat4(rotateXYZ(m_rotation), m_position);
	}
	void ControlView()
	{
		vec2 center = this->GetScreenCenter();

		if(Input::MousePressed(1))
		{
			Input::MouseSetPos(center[0], center[1]);
		}
		if(Input::MousePress(1))
		{	
			vec2 off = this->GetMouseOff();

			m_rotation[0] += off[1] / 2 * m_rotate_speed;
			m_rotation[1] += off[0] / 2 * m_rotate_speed;
			m_rotation[2] = 0;

			m_rotation[0] = clamp(m_rotation[0], - PI_2 + 0.1, PI_2 - 0.1);
			m_rotation[1] = fmodf(m_rotation[1], PIx2);	

			Input::MouseSetPos(center[0], center[1]);
		}

		float distance = length(m_position);

		distance += Input::MouseWheel() * (m_move_speed + distance * 0.1);//distance * 0.1�����������и��ٶ�����

		distance = max(0, distance);

		m_position = -vec3Z * rotateXYZ(m_rotation) * distance;	
	}
	void Perform()//left hand for scene
	{
		//opgl��y����������Ļ�����෴
		int ww, wh;
		Window::GetSize(ww, wh);
		//viewport
		glViewport(m_vx, wh - m_vy - m_vh, m_vw, m_vh);
		//
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();	
		glMultMatrixf(this->GetProj());
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		glMultMatrixf(this->GetView());

		if(m_proj_type == eOrtho)
		{
			glDisable(GL_CULL_FACE);
			glDisable(GL_LIGHTING);
		}
		else
		{
			glEnable(GL_CULL_FACE);
			glEnable(GL_LIGHTING);
			//glLightfv(GL_LIGHT0, GL_POSITION, ToVec4(camera.m_position, 1));//��ʱ����light_pos��������ƶ����ڹ۲� ��������Ų������ӽ��ƶ�	
		}
		
	}
	void PerformGui()
	{
		//opgl��y����������Ļ�����෴
		int ww, wh;
		Window::GetSize(ww, wh);
		//viewport
		glViewport(m_vx, wh - m_vy - m_vh, m_vw, m_vh);
		//
		glDisable(GL_CULL_FACE);
		glDisable(GL_LIGHTING);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();	
		glMultMatrixf(ortho(m_vw, m_vh, 0.1, 3000));//gluOrtho2D(0, g_window_w, g_window_h, 0);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();	
		glMultMatrixf(lookat(vec3(0, 0, -300), vec3Z, vec3Y));	
	}

	Type m_proj_type;
	float m_proj_width;
	float m_proj_height;
	float m_vx;
	float m_vy;
	float m_vw;
	float m_vh;
	float m_move_speed;
	float m_rotate_speed;
	vec3 m_position;
	vec3 m_rotation;
};

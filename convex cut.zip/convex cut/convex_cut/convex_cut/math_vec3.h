class vec3
{
public:
	inline vec3(){}
	inline vec3(const vec3& that)
	{
		for (int n = 0; n < 3; n++)
			data[n] = that.data[n];
	}
	explicit inline vec3(const float& s)
	{
		for (int n = 0; n < 3; n++)
		{
			data[n] = s;
		}
	}

	inline vec3&	operator=(const vec3& that)
	{
		for (int n = 0; n < 3; n++)
			data[n] = that.data[n];
		return *this;
	}
	inline vec3		operator-() const
	{
		vec3 result;
		for (int n = 0; n < 3; n++)
			result.data[n] = -data[n];
		return result;
	}
	inline vec3		operator-(const vec3& that) const
	{
		vec3 result;
		for (int n = 0; n < 3; n++)
			result.data[n] = data[n] - that.data[n];
		return result;
	}
	inline vec3		operator+() const
	{
		return *this;
	}
	inline vec3		operator+(const vec3& that) const
	{
		vec3 result;
		for (int n = 0; n < 3; n++)
			result.data[n] = data[n] + that.data[n];
		return result;
	}
	inline vec3		operator*(const vec3& that) const
	{
		vec3 result;
		for (int n = 0; n < 3; n++)
			result.data[n] = data[n] * that.data[n];
		return result;
	}
	inline vec3		operator*(const float& that) const
	{
		vec3 result;
		for (int n = 0; n < 3; n++)
			result.data[n] = data[n] * that;
		return result;
	}
	inline vec3		operator/(const vec3& that) const
	{
		vec3 result;
		for (int n = 0; n < 3; n++)
			result.data[n] = data[n] / that.data[n];
		return result;
	}
	inline vec3		operator/(const float& that) const
	{
		vec3 result;
		float _l = 1.0f / that;
		for (int n = 0; n < 3; n++)
			result.data[n] = data[n] * _l;
		return result;
	}
	inline vec3&	operator+=(const vec3& that)
	{
		return (*this = *this + that);//����������ֵ,��Ҫ�Ⱥ�
	}
	inline vec3&	operator-=(const vec3& that)
	{
		return (*this = *this - that);
	}
	inline vec3&	operator*=(const vec3& that)
	{
		return (*this = *this * that);
	}
	inline vec3&	operator*=(const float& that)
	{
		return (*this = *this * that);
	}
	inline vec3&	operator/=(const vec3& that)
	{
		return (*this = *this / that);
	}
	inline vec3&	operator/=(const float& that)
	{
		return (*this = *this / that);
	}
	inline bool		operator==(const vec3& that)
	{
		for(int n = 0; n < 3; n++){
			if(data[n] != that.data[n])
				return false;
		}
		return true;
	}
	inline bool		operator!=(const vec3& that)
	{
		for(int n = 0; n < 3; n++){
			if(data[n] != that.data[n])
				return true;
		}
		return false;
	}
	//��дconst,���޷�����const����
	//ֻдconst,���ܷ���ֵ�ı�������Ϊconst,�����޸�
	inline float&		operator[](int n) {return data[n];}
	inline const float& operator[](int n) const {return data[n];}
	//ת���
	inline		operator		float* ()		{return &data[0];}
	inline		operator const	float* () const {return &data[0];}
	float data[3];

	inline vec3(const float& x, const float& y, const float& z)
	{
		data[0] = x;
		data[1] = y;
		data[2] = z;
	}
};
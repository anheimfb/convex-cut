class Window
{
public:
	static void SetFPS(int fps)
	{
		if(fps == 0)
			m_secondPerFrameRequired = 0;
		else
			m_secondPerFrameRequired = 1.0f / fps;
	}
	static double GetFPS()
	{
		return m_FPS;
	}
	static void Create(int x, int y, int w, int h);
	static void Destroy();
	static void LoopBegin();
	static void LoopEnd();
	static void SetClose();
	static void SetPos(int x, int y);
	static void SetSize(int w, int h);
	static bool GetClose();
	static void GetPos(int& x, int& y);
	static void GetSize(int& w, int& h);
	//----------------------------------
	static double m_FPS;
	static double m_secondPerFrameRequired;
	static double m_second;
};
double Window::m_FPS = 0;
double Window::m_secondPerFrameRequired = 0;
double Window::m_second = 0;

class Input
{
public:
	static bool	KeyPress(int key)
	{
		assert(key >= 0 && key < m_key_num);

		return m_key[key] == PRESS || m_key[key] == PRESSED;
	}
	static bool	KeyPressed(int key)
	{
		assert(key >= 0 && key < m_key_num);

		return m_key[key] == PRESSED;
	}
	static bool	KeyReleased(int key)
	{
		assert(key >= 0 && key < m_key_num);

		return m_key[key] == RELEASED;
	}
	static bool	MousePress(int key)//0 left 1 right
	{
		assert(key >= 0 && key < 2);

		return m_mouse[key] == PRESS || m_mouse[key] == PRESSED;
	}
	static bool	MousePressed(int key)//0 left 1 right
	{
		assert(key >= 0 && key < 2);

		return m_mouse[key] == PRESSED;
	}
	static bool	MouseReleased(int key)//0 left 1 right
	{
		assert(key >= 0 && key < 2);

		return m_mouse[key] == RELEASED;
	}
	static int	MouseWheel()
	{
		return m_mouse_wheel;
	}
	static void MouseGetPos(double& x, double& y);
	static void MouseSetPos(double x, double y);
	//-------------------------------------
	static const int	RELEASE	= 0;
	static const int	PRESS = 1;
	static const int	RELEASED = 2;
	static const int	PRESSED	= 3;
	static const int	m_key_num = 256;
	static int			m_key[m_key_num];//0 release,1 press, 2 pressed, 3released
	static int			m_mouse[3];
	static int			m_mouse_wheel;
};
int Input::m_key[m_key_num] = {0};
int Input::m_mouse[3] = {0};
int Input::m_mouse_wheel = 0;
class vec4
{
public:
	inline vec4(){}
	inline vec4(const vec4& that)
	{
		for (int n = 0; n < 4; n++)
			data[n] = that.data[n];
	}
	explicit inline vec4(const float& s)
	{
		for (int n = 0; n < 4; n++)
		{
			data[n] = s;
		}
	}

	inline vec4&	operator=(const vec4& that)
	{
		for (int n = 0; n < 4; n++)
			data[n] = that.data[n];
		return *this;
	}
	inline vec4		operator-() const
	{
		vec4 result;
		for (int n = 0; n < 4; n++)
			result.data[n] = -data[n];
		return result;
	}
	inline vec4		operator-(const vec4& that) const
	{
		vec4 result;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] - that.data[n];
		return result;
	}
	inline vec4		operator+() const
	{
		return *this;
	}
	inline vec4		operator+(const vec4& that) const
	{
		vec4 result;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] + that.data[n];
		return result;
	}
	inline vec4		operator*(const vec4& that) const
	{
		vec4 result;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] * that.data[n];
		return result;
	}
	inline vec4		operator*(const float& that) const
	{
		vec4 result;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] * that;
		return result;
	}
	inline vec4		operator/(const vec4& that) const
	{
		vec4 result;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] / that.data[n];
		return result;
	}
	inline vec4		operator/(const float& that) const
	{
		vec4 result;
		float _l = 1.0f / that;
		for (int n = 0; n < 4; n++)
			result.data[n] = data[n] * _l;
		return result;
	}
	inline vec4&	operator+=(const vec4& that)
	{
		return (*this = *this + that);//����������ֵ,��Ҫ�Ⱥ�
	}
	inline vec4&	operator-=(const vec4& that)
	{
		return (*this = *this - that);
	}
	inline vec4&	operator*=(const vec4& that)
	{
		return (*this = *this * that);
	}
	inline vec4&	operator*=(const float& that)
	{
		return (*this = *this * that);
	}
	inline vec4&	operator/=(const vec4& that)
	{
		return (*this = *this / that);
	}
	inline vec4&	operator/=(const float& that)
	{
		return (*this = *this / that);
	}
	inline bool		operator==(const vec4& that)
	{
		for(int n = 0; n < 4; n++){
			if(data[n] != that.data[n])
				return false;
		}
		return true;
	}
	inline bool		operator!=(const vec4& that)
	{
		for(int n = 0; n < 4; n++){
			if(data[n] != that.data[n])
				return true;
		}
		return false;
	}
	//��дconst,���޷�����const����
	//ֻдconst,���ܷ���ֵ�ı�������Ϊconst,�����޸�
	inline float&		operator[](int n) {return data[n];}
	inline const float& operator[](int n) const {return data[n];}
	//ת���
	inline		operator		float* ()		{return &data[0];}
	inline		operator const	float* () const {return &data[0];}
	float data[4];

	inline vec4(const float& x, const float& y, const float& z, const float& w)
	{
		data[0] = x;
		data[1] = y;
		data[2] = z;
		data[3] = w;
	}
};
static vector<string>	g_debug_string;
static vector<vec3>		g_debug_string_pos;

void static inline DrawTest()
{
	int ww, wh;
	Window::GetSize(ww, wh);

	glUseProgram(0);	
	glViewport(0, 0, ww, wh);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);	

	glMatrixMode(GL_PROJECTION);//ѡ��ͶӰ����
	glLoadIdentity();			//����ͶӰ����	
	gluPerspective(45.0f, (GLfloat)ww/(GLfloat)wh, 0.1f, 100.0f);//�����ӿڴ�С
	glMatrixMode(GL_MODELVIEW);	//ѡ��ģ�͹۲����
	glLoadIdentity();			//����ģ�͹۲����
	static float g_Angle = 0;
	g_Angle +=  15.0f;							
	glLoadIdentity();											
	glTranslatef(0.0f, 0.0f, -6.0f);							
	glRotatef(g_Angle, 0.0f, 1.0f, 0.0f);						
	glRotatef(g_Angle * 0.7f, -1.0f, 0.0f, 0.0f);				

	for (int rot1 = 0; rot1 < 2; rot1++)						
	{
		glRotatef(90.0f, 0.0f, 1.0f, 0.0f);						
		glRotatef(180.0f, 1.0f, 0.0f, 0.0f);					
		for (int rot2 = 0; rot2 < 2; rot2++)					
		{
			glRotatef(180.0f, 0.0f, 1.0f, 0.0f);				
			glBegin(GL_TRIANGLES);								
				glColor3f(1.f, 0.f, 0.f);	glVertex3f( 0.0f,  1.0f, 0.0f);
				glColor3f(0.f, 1.f, 0.f);	glVertex3f(-1.0f, -1.0f, 1.0f);
				glColor3f(0.f, 0.f, 1.f);	glVertex3f( 1.0f, -1.0f, 1.0f);
			glEnd();											
		}
	}
}
void static inline DrawString(float x, float y, string str) 
{  			
	static bool setup = true;
	static int lists;
	if(setup) 
	{                 
		setup = 0;        
		lists = glGenLists(128);// ����MAX_CHAR����������ʾ�б���� 
		wglUseFontBitmaps(wglGetCurrentDC(), 0, 128, lists);// ��ÿ���ַ��Ļ������װ����Ӧ����ʾ�б���
	}
		
	glRasterPos2f(x,y);     
	for(int i = 0;i < str.size(); i++)// ����ÿ���ַ���Ӧ����ʾ�б�������ÿ���ַ�
	{
		glCallList(lists + str[i]);
	}

	glColor4f(1, 1, 1, 1);
}
void static inline DrawStringCN(float x, float y, string str) 
{					
	// �����ַ��ĸ���
	int len = 0;
	for(int i=0;i < str.size(); ++i)
	{
		if( IsDBCSLeadByte(str[i]) )// �����˫�ֽ��ַ��ģ����������ַ����������ֽڲ���һ���ַ�
			++i;
		++len;
	}

	// ������ַ�ת��Ϊ���ַ�
	wchar_t* wstring = (wchar_t*)malloc((len+1) * sizeof(wchar_t));
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, str.c_str(), -1, wstring, len);
	wstring[len] = L'\0';

	// �������ַ�	
	glRasterPos2f(x,y);
	GLuint list = glGenLists(1);		
	for(int i=0; i<len; ++i)
	{
		wglUseFontBitmapsW(wglGetCurrentDC(), wstring[i], 1, list);
		glCallList(list);
	}
	glDeleteLists(list, 1);

	free(wstring);

	glColor4f(1, 1, 1, 1);
}
void static inline DebugAddString(string str, vec3 pos)
{
	//add string and pos for ortho ���Ƶ�ʱ��pos��Ҫת��vec2
	g_debug_string.push_back(str);
	g_debug_string_pos.push_back(pos);
}
void static inline DebugStrings(mat4 tmV, mat4 tmP, float vw, float vh)
{
	glDisable(GL_TEXTURE_2D);
	//���Ƶ�ʱ��pos��Ҫת��vec2
	vec4 p;
	float x,y;
	mat4 tmVP = tmV * tmP;
	for(int i = 0; i < g_debug_string.size(); i++)
	{
		vec3 pos = g_debug_string_pos[i];
		p = ToVec4(pos, 1) * tmVP;
		if(p[3])//�� view��zΪ0�������м�
		{
			x = p[0] * vw * 0.5 / p[3];
			y = p[1] * vh * 0.5 / p[3];	
			/*
			p / p[3] * inverse(orthoProj)??
			*/
		}
		else
		{
			x = 0;
			y = 0;	
		}
		glColor4f(0, 1, 0, 1);
		DrawString(x, y, g_debug_string[i]);
	}
	g_debug_string.clear();
	g_debug_string_pos.clear();
}
void static inline DebugTriangle(vec3 A, vec3 B, vec3 C, vec4 color = vec4(1, 1, 1, 0.5))
{
	//���߻��ܾ�������Ӱ��, ��Ҫ�Լ�����ֵ
	//��͸������Ҫ�Ȼ���,����û�б���͸���ڵ���Ч��
	glDepthMask(GL_FALSE);

	glColor4f(0.8, 0, 0, 1);
	glDisable(GL_LIGHTING);
	glLineWidth(2);
	//normal
	vec3 n;
	if(FaceNormal(n, A, B, C))
	{
		//n���ܾ�������
		//glBegin(GL_LINES);
		//glVertex3fv((A + B + C) / 3);
		//glVertex3fv((A + B + C) / 3 + n * 0.2);
		//glEnd();
	}
	else
	{
		MsgBox("bad face");
		exit(0);
	}
	//edge	
	glBegin(GL_LINE_LOOP);
	glVertex3fv(A);
	glVertex3fv(B);
	glVertex3fv(C);
	glVertex3fv(A);
	glEnd();
	glLineWidth(1);

	glColor4fv(color);
	glEnable(GL_LIGHTING);
	//face
	glBegin(GL_TRIANGLES);
	glNormal3fv(n);
	glVertex3fv(A);
	glVertex3fv(B);
	glVertex3fv(C);
	glEnd();

	glDepthMask(GL_TRUE);
	glColor4f(1, 1, 1, 1);
}
void static inline draw_point(vec2 v)
{
	glBegin(GL_POINTS);
	glVertex3f(v[0], v[1], 0);
	glEnd();

	glPointSize(1);
	glColor4f(1, 1, 1, 1);
}
void static inline draw_point(vec3 v)
{
	glBegin(GL_POINTS);
	glVertex3f(v[0], v[1], v[2]);
	glEnd();

	glPointSize(1);
	glColor4f(1, 1, 1, 1);
}
void static inline draw_line(vec2 v1, vec2 v2)
{
	glBegin(GL_LINES);
	glVertex3f(v1[0], v1[1], 0);
	glVertex3f(v2[0], v2[1], 0);
	glEnd();
	glLineWidth(1);
	glColor4f(1, 1, 1, 1);
}
void static inline draw_line(vec3 v1, vec3 v2)
{
	glBegin(GL_LINES);
	glVertex3f(v1[0], v1[1], v1[2]);
	glVertex3f(v2[0], v2[1], v2[2]);
	glEnd();
	glLineWidth(1);
	glColor4f(1, 1, 1, 1);	
}
void static inline draw_quad_wire(float x1, float y1, float x2, float y2)
{
	glBegin(GL_LINE_LOOP);
	glVertex3f(x1, y2, 0);
	glVertex3f(x2, y2, 0);//��������ϵ ˳ʱ��
	glVertex3f(x2, y1, 0);
	glVertex3f(x1, y1, 0);
	glVertex3f(x1, y2, 0);
	glEnd();

	glLineWidth(1);
	glColor4f(1, 1, 1, 1);		
}
void static inline draw_circle_wire(float x, float y, float radius)
{
	glBegin(GL_LINES);
	const float k_segments = 16.0f;//��16������
	const float k_increment = 2.0f * PI / k_segments;
    float sinInc = sinf(k_increment);
    float cosInc = cosf(k_increment);
    vec2 r1(1.0f, 0.0f);
    vec2 v1 = radius * r1;
	for (int i = 0; i < k_segments; ++i)
	{
        // Perform rotation to avoid additional trigonometry.
        vec2 r2;
        r2[0] = cosInc * r1[0] - sinInc * r1[1];
        r2[1] = sinInc * r1[0] + cosInc * r1[1];
		vec2 v2 = radius * r2;
		glVertex3f(x + v1[0], y + v1[1], 0);
		glVertex3f(x + v2[0], y + v2[1], 0);
        r1 = r2;
        v1 = v2;
	}
	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
	glVertex3f(x, y, 0);
	glVertex3f(x + radius, y + 0, 0);
	glEnd();

	glLineWidth(1);
	glColor4f(1, 1, 1, 1);
}
void static inline draw_polygon_wire(const vec2* vertices, const int vertexCount)
{
	glBegin(GL_LINES);
	vec2 p1 = vertices[vertexCount - 1];
	for (int i = 0; i < vertexCount; ++i)
	{
        vec2 p2 = vertices[i];
		glVertex3f(p1[0], p1[1], 0);
		glVertex3f(p2[0], p2[1], 0);
        p1 = p2;
	}
	glEnd();

	glPointSize(4);
	glBegin(GL_POINTS);
	glVertex3f(0, 0, 0);
	glEnd();

	glPointSize(1);
	glLineWidth(1);
	glColor4f(1, 1, 1, 1);
}
void static inline draw_plane()
{
	glDisable(GL_LIGHTING);
	//����ԲȦ
	glColor3f(0.75, 0.75, 0.75);
	for (unsigned i = 1; i < 20; i++)
	{
		glBegin(GL_LINE_LOOP);
		for (unsigned j = 0; j < 32; j++)
		{
			float theta = PI * j / 16.0f;
			glVertex3f(i*cosf(theta),0.0f,i*sinf(theta));
		}
		glEnd();
	}
	//�м��ʮ����
	glBegin(GL_LINES);
	glVertex3f(-20,0,0);
	glVertex3f(20,0,0);
	glVertex3f(0,0,-20);
	glVertex3f(0,0,20);
	glEnd();

	glLineWidth(1);
	glColor4f(1, 1, 1, 1);
	glEnable(GL_LIGHTING);
}
void static inline draw_grid()
{
	glDisable(GL_LIGHTING);

	glBegin(GL_LINES);
	int w = 20;
	for(int i = 0; i <= w * 2; i++)
	for(int j = 0; j <= w * 2; j++)
	{
		glVertex3f(-w + i, 0, -w);
		glVertex3f(-w + i, 0, w);

		glVertex3f(-w, 0, -w + j);
		glVertex3f(w, 0, -w + j);
	}
	glEnd();

	glLineWidth(1);
	glColor4f(1, 1, 1, 1);
	glEnable(GL_LIGHTING);
}
void static inline draw_coordinate()
{
	//������
	glDisable(GL_LIGHTING);	
	glPointSize(8);
	glColor3f(0, 0, 0);
	draw_point(vec3Zero);
	glLineWidth(4);
	glColor3f(1, 0, 0);
	draw_line(vec3Zero, vec3(1, 0, 0));
	glLineWidth(4);
	glColor3f(0, 1, 0);
	draw_line(vec3Zero, vec3(0, 1, 0));
	glLineWidth(4);
	glColor3f(0, 0, 1);
	draw_line(vec3Zero, vec3(0, 0, 1));
	glEnable(GL_LIGHTING);	
}
void static inline draw_point_list(vector<vec3>& v_v, mat4 m)
{
	glDisable(GL_LIGHTING);
	
	glPushMatrix();
	glMultMatrixf(m);

	glBegin(GL_POINTS);
	for(int i = 0; i < v_v.size(); i++)
	{
		glVertex3fv(v_v[i]);
	}
	glEnd();

	glPopMatrix();

	glPointSize(1);
	glColor4f(1, 1, 1, 1);

	glEnable(GL_LIGHTING);
}
void static inline draw_triangle_wire(vec2 A, vec2 B, vec2 C)
{
	glBegin(GL_LINE_LOOP);
	glVertex2fv(A);
	glVertex2fv(B);
	glVertex2fv(C);
	glVertex2fv(A);
	glEnd();

	glLineWidth(1);
	glColor4f(1, 1, 1, 1);
}
void static inline draw_triangle_wire(vec3 A, vec3 B, vec3 C)
{
	glBegin(GL_LINE_LOOP);
	glVertex3fv(A);
	glVertex3fv(B);
	glVertex3fv(C);
	glVertex3fv(A);
	glEnd();

	glLineWidth(1);
	glColor4f(1, 1, 1, 1);
}
void static inline draw_triangle_ext(vec3 A, vec3 B, vec3 C, mat4 m)
{

}
void static inline draw_box(float x = 0, float y = 0, float z = 0, float w = 1)
{
	glBegin(GL_QUADS);
	//back
	glNormal3f(0, 0, -1);
	glVertex3f(x - w, y + w, z -w);
	glVertex3f(x + w, y + w, z -w);
	glVertex3f(x + w, y - w, z -w);
	glVertex3f(x - w, y - w, z -w);
	//forward
	glNormal3f(0, 0, 1);
	glVertex3f(x + w, y + w, z + w);
	glVertex3f(x - w, y + w, z + w);
	glVertex3f(x - w, y - w, z + w);
	glVertex3f(x + w, y - w, z + w);
	//left
	glNormal3f(-1, 0, 0);
	glVertex3f(x - w, y - w, z + w);
	glVertex3f(x - w, y + w, z + w);
	glVertex3f(x - w, y + w, z - w);
	glVertex3f(x - w, y - w, z - w);
	//right
	glNormal3f(1, 0, 0);
	glVertex3f(x + w, y + w, z + w);
	glVertex3f(x + w, y - w, z + w);
	glVertex3f(x + w, y - w, z - w);
	glVertex3f(x + w, y + w, z - w);
	//up
	glNormal3f(0, 1, 0);
	glVertex3f(x - w, y + w, z + w);
	glVertex3f(x + w, y + w, z + w);
	glVertex3f(x + w, y + w, z - w);
	glVertex3f(x - w, y + w, z - w);
	//down
	glNormal3f(0, -1, 0);
	glVertex3f(x + w, y - w, z + w);
	glVertex3f(x - w, y - w, z + w);
	glVertex3f(x - w, y - w, z - w);
	glVertex3f(x + w, y - w, z - w);

	glEnd();

	glColor4f(1, 1, 1, 1);
}
void static inline draw_box_wire()
{

}
void static inline draw_select_font(int size, int charset, const char* face) 
{
	HFONT hFont = CreateFontA(size, 0, 0, 0, FW_MEDIUM, 0, 0, 0,
		charset, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, face);
	HFONT hOldFont = (HFONT)SelectObject(wglGetCurrentDC(), hFont);
	DeleteObject(hOldFont);
}	
void static inline draw_sprite(GLuint t, float x, float y, float w, float h, float x1, float y1, float x2, float y2, float offx, float offy)
{
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, t);

	glBegin(GL_QUADS);
	glTexCoord2f(x1, y1);glVertex3f(x + offx,		y + offy, 0);
	glTexCoord2f(x2, y1);glVertex3f(x + offx + w,	y + offy, 0);
	glTexCoord2f(x2, y2);glVertex3f(x + offx + w,	y + offy + h, 0);
	glTexCoord2f(x1, y2);glVertex3f(x + offx,		y + offy + h, 0);
	glEnd();

	glColor4f(1, 1, 1, 1);
	glDisable(GL_TEXTURE_2D);
}
void static inline DrawBox(vec3 halfSize, mat4 m)
{
	glPushMatrix();
	glMultMatrixf(m);

	float w = halfSize[0];
	float h = halfSize[1];
	float l = halfSize[2];
	glBegin(GL_QUADS);
	//back
	glNormal3f(0, 0, -1);
	glTexCoord2f(0, 0);glVertex3f(- w, + h, - l);
	glTexCoord2f(1, 0);glVertex3f(+ w, + h, - l);
	glTexCoord2f(1, 1);glVertex3f(+ w, - h, - l);
	glTexCoord2f(0, 1);glVertex3f(- w, - h, - l);
	//forward
	glNormal3f(0, 0, 1);
	glTexCoord2f(0, 0);glVertex3f(+ w, + h, + l);
	glTexCoord2f(1, 0);glVertex3f(- w, + h, + l);
	glTexCoord2f(1, 1);glVertex3f(- w, - h, + l);
	glTexCoord2f(0, 1);glVertex3f(+ w, - h, + l);
	//left
	glNormal3f(-1, 0, 0);
	glTexCoord2f(0, 0);glVertex3f(- w, - h, + l);
	glTexCoord2f(1, 0);glVertex3f(- w, + h, + l);
	glTexCoord2f(1, 1);glVertex3f(- w, + h, - l);
	glTexCoord2f(0, 1);glVertex3f(- w, - h, - l);
	//right
	glNormal3f(1, 0, 0);
	glTexCoord2f(0, 0);glVertex3f(+ w, + h, + l);
	glTexCoord2f(1, 0);glVertex3f(+ w, - h, + l);
	glTexCoord2f(1, 1);glVertex3f(+ w, - h, - l);
	glTexCoord2f(0, 1);glVertex3f(+ w, + h, - l);
	//up
	glNormal3f(0, 1, 0);
	glTexCoord2f(0, 0);glVertex3f(- w, + h, + l);
	glTexCoord2f(1, 0);glVertex3f(+ w, + h, + l);
	glTexCoord2f(1, 1);glVertex3f(+ w, + h, - l);
	glTexCoord2f(0, 1);glVertex3f(- w, + h, - l);
	//down
	glNormal3f(0, -1, 0);
	glTexCoord2f(0, 0);glVertex3f(+ w, - h, + l);
	glTexCoord2f(1, 0);glVertex3f(- w, - h, + l);
	glTexCoord2f(1, 1);glVertex3f(- w, - h, - l);
	glTexCoord2f(0, 1);glVertex3f(+ w, - h, - l);

	glEnd();

	glPopMatrix();
	glColor4f(1, 1, 1, 1);
}
void static inline DrawBoxWire(vec3 halfSize)
{
	float w = halfSize[0];
	float h = halfSize[1];
	float l = halfSize[2];
	glBegin(GL_LINES);//8����

	glVertex3f(- w, + h, - l);
	glVertex3f(+ w, + h, - l);

	glVertex3f(+ w, - h, - l);
	glVertex3f(- w, - h, - l);

	glVertex3f(+ w, + h, + l);
	glVertex3f(- w, + h, + l);

	glVertex3f(- w, - h, + l);
	glVertex3f(+ w, - h, + l);

	glVertex3f(- w, + h, + l);
	glVertex3f(- w, + h, - l);

	glVertex3f(- w, - h, + l);
	glVertex3f(- w, - h, - l);

	glVertex3f(+ w, + h, + l);
	glVertex3f(+ w, + h, - l);

	glVertex3f(+ w, - h, + l);
	glVertex3f(+ w, - h, - l);
		
	glEnd();

	glColor4f(1, 1, 1, 1);
}
void static inline DrawCylinder(float radius, float height)
{
	int uStepNum = 16;
	int vStepNum = 16;
	float ustep = 1 / (float)uStepNum;
	float vstep = 1 / (float)vStepNum;

	mat3 urot = rotateY(ustep * PIx2);
	mat3 vrot = rotateX(vstep * PIx2);
		
	vec3 vert1;
	vec3 vert2;
	//����Բ��
	vert1 = vec3(radius, -height * 0.5, 0);
	vert2 = vert1 * urot;
	for(int j = 0; j < uStepNum; j++)
	{
		vec3 a = vert1 * urot;
		vec3 b = vert2 * urot;
		vec3 c = b + vec3(0, height, 0);
		vec3 d = a + vec3(0, height, 0);

		glBegin(GL_QUADS);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3fv(a);
		glVertex3fv(b);
		glVertex3fv(c);
		glVertex3fv(d);
		glEnd();

		glBegin(GL_TRIANGLES);
		glNormal3fv(vec3Y);
		glVertex3fv(vec3Y * height * 0.5);
		glVertex3fv(d);
		glVertex3fv(c);
		glEnd();

		glBegin(GL_TRIANGLES);
		glNormal3fv(-vec3Y);
		glVertex3fv(-vec3Y * height * 0.5);
		glVertex3fv(b);
		glVertex3fv(a);
		glEnd();

		vert1 = a;
		vert2 = b;
	}
}
void static inline DrawCylinderWire(float radius, float height)
{
	int uStepNum = 16;
	int vStepNum = 16;
	float ustep = 1 / (float)uStepNum;
	float vstep = 1 / (float)vStepNum;

	mat3 urot = rotateY(ustep * PIx2);
	mat3 vrot = rotateX(vstep * PIx2);
		
	vec3 vert1;
	vec3 vert2;
	//����Բ��
	vert1 = vec3(radius, -height * 0.5, 0);
	vert2 = vert1 * urot;
	for(int j = 0; j < uStepNum; j++)
	{
		vec3 a = vert1 * urot;
		vec3 b = vert2 * urot;
		vec3 c = b + vec3(0, height, 0);
		vec3 d = a + vec3(0, height, 0);

		glBegin(GL_LINE_LOOP);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3fv(a);
		glVertex3fv(b);
		glVertex3fv(c);
		glVertex3fv(d);
		glVertex3fv(a);
		glEnd();

		glBegin(GL_LINE_LOOP);
		glNormal3fv(vec3Y);
		glVertex3fv(vec3Y * height * 0.5);
		glVertex3fv(d);
		glVertex3fv(c);
		glVertex3fv(vec3Y * height * 0.5);
		glEnd();

		glBegin(GL_LINE_LOOP);
		glNormal3fv(-vec3Y);
		glVertex3fv(-vec3Y * height * 0.5);
		glVertex3fv(b);
		glVertex3fv(a);
		glVertex3fv(-vec3Y * height * 0.5);
		glEnd();

		vert1 = a;
		vert2 = b;
	}
}
void static inline DrawCone(float radius, float height)
{
	const float k_segments = 16.0f;//��16������
	const float k_increment = 2.0f * PI / k_segments;
	mat3 rot = rotateY(k_increment);
	vec3 v_top = vec3(0, height * 0.5, 0);
	vec3 v_down = vec3(0, -height * 0.5, 0);
	vec3 v1(radius, -height * 0.5, 0.0f);

	glBegin(GL_TRIANGLES);
	for (int i = 0; i < k_segments; ++i)
	{
		vec3 v2 = v1 * rot;
		vec3 normal = normalize(cross(v1 - v_top, v2 - v_top));
		glNormal3fv(normal);
		glVertex3fv(v_top);
		glVertex3fv(v1);
		glVertex3fv(v2);

		glNormal3fv(-vec3Y);
		glVertex3fv(v_down);
		glVertex3fv(v2);
		glVertex3fv(v1);
			
		v1 = v2;
	}
	glEnd();
}
void static inline DrawConeWire(float radius, float height)
{
	const float k_segments = 16.0f;//��16������
	const float k_increment = 2.0f * PI / k_segments;
	mat2 rot = rotate2(k_increment);
	vec2 v1(radius, 0.0f);

	glBegin(GL_LINES);
	for (int i = 0; i < k_segments; ++i)
	{
		vec2 v2 = v1 * rot;

		glVertex3f(v1[0], -height * 0.5, v1[1]);
		glVertex3f(v2[0], -height * 0.5, v2[1]);

		glVertex3f(0, height * 0.5, 0);
		glVertex3f(v2[0], -height * 0.5, v2[1]);

		glVertex3f(0, height * 0.5, 0);
		glVertex3f(v1[0], -height * 0.5, v1[1]);
			
		v1 = v2;
	}
	glEnd();
	}
void static inline DrawCapsule(float radius, float height)
{
	int uStepNum = 16;
	int vStepNum = 16;
	float ustep = 1 / (float)uStepNum;
	float vstep = 1 / (float)vStepNum;

	mat3 urot = rotateY(ustep * PIx2);
	mat3 vrot = rotateX(vstep * PIx2);
		
	vec3 vert1;
	vec3 vert2;
	//�����϶���������
	vert1 = vec3(0, radius, 0);
	vert2 = vert1 * vrot;
	for(int i = 0; i < uStepNum; i++)
	{
		vec3 a = vert1;
		vec3 b = vert2;
		vec3 c = vert2 * urot;
			
		glBegin(GL_TRIANGLES);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3f(a[0], a[1] + height * 0.5, a[2]);
		glVertex3f(b[0], b[1] + height * 0.5, b[2]);
		glVertex3f(c[0], c[1] + height * 0.5, c[2]);
		glEnd();

		vert2 = c;
	}
	//����Բ�ı�����
	vert1 = vec3(0, radius, 0) * vrot;
	vert2 = vert1 * vrot;
	for(int i = 1; i < vStepNum / 2 - 1; i++)
	{
		vec3 vertu1 = vert1;
		vec3 vertu2 = vert2;
		if(i < vStepNum / 4)
		{
			for(int j = 0; j < uStepNum; j++)
			{
				vec3 a = vertu1;
				vec3 b = vertu2;
				vec3 c = vertu2 * urot;
				vec3 d = vertu1 * urot;

				glBegin(GL_QUADS);
				glNormal3fv(normalize(cross(b - a, c - a)));
				glVertex3f(a[0], a[1] + height * 0.5, a[2]);
				glVertex3f(b[0], b[1] + height * 0.5, b[2]);
				glVertex3f(c[0], c[1] + height * 0.5, c[2]);
				glVertex3f(d[0], d[1] + height * 0.5, d[2]);
				glEnd();

				vertu1 = d;
				vertu2 = c;
			}
		}
		else
		{
			for(int j = 0; j < uStepNum; j++)
			{
				vec3 a = vertu1;
				vec3 b = vertu2;
				vec3 c = vertu2 * urot;
				vec3 d = vertu1 * urot;

				glBegin(GL_QUADS);
				glNormal3fv(normalize(cross(b - a, c - a)));
				glVertex3f(a[0], a[1] - height * 0.5, a[2]);
				glVertex3f(b[0], b[1] - height * 0.5, b[2]);
				glVertex3f(c[0], c[1] - height * 0.5, c[2]);
				glVertex3f(d[0], d[1] - height * 0.5, d[2]);
				glEnd();

				vertu1 = d;
				vertu2 = c;
			}
		}
		vert1 = vert1 * vrot;
		vert2 = vert2 * vrot;
	}
	//�����¶���������
	vert1 = vec3(0, -radius, 0);
	vert2 = vert1 * vrot;
	for(int i = 0; i < uStepNum; i++)
	{
		vec3 a = vert1;
		vec3 c = vert2;
		vec3 b = vert2 * urot;
			
		glBegin(GL_TRIANGLES);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3f(a[0], a[1] - height * 0.5, a[2]);
		glVertex3f(b[0], b[1] - height * 0.5, b[2]);
		glVertex3f(c[0], c[1] - height * 0.5, c[2]);
		glEnd();

		vert2 = b;
	}
	//����Բ��
	vert1 = vec3(radius, -height * 0.5, 0);
	vert2 = vert1 * urot;
	for(int j = 0; j < uStepNum; j++)
	{
		vec3 a = vert1 * urot;
		vec3 b = vert2 * urot;
		vec3 c = b + vec3(0, height, 0);
		vec3 d = a + vec3(0, height, 0);
		glBegin(GL_QUADS);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3fv(a);
		glVertex3fv(b);
		glVertex3fv(c);
		glVertex3fv(d);
		glEnd();

		vert1 = a;
		vert2 = b;
	}
}
void static inline DrawCapsuleWire(float radius, float height)
{
	int uStepNum = 16;
	int vStepNum = 16;
	float ustep = 1 / (float)uStepNum;
	float vstep = 1 / (float)vStepNum;

	mat3 urot = rotateY(ustep * PIx2);
	mat3 vrot = rotateX(vstep * PIx2);
		
	vec3 vert1;
	vec3 vert2;
	//�����϶���������
	vert1 = vec3(0, radius, 0);
	vert2 = vert1 * vrot;
	for(int i = 0; i < uStepNum; i++)
	{
		vec3 a = vert1;
		vec3 b = vert2;
		vec3 c = vert2 * urot;
			
		glBegin(GL_LINE_LOOP);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3f(a[0], a[1] + height * 0.5, a[2]);
		glVertex3f(b[0], b[1] + height * 0.5, b[2]);
		glVertex3f(c[0], c[1] + height * 0.5, c[2]);
		glVertex3f(a[0], a[1] + height * 0.5, a[2]);
		glEnd();

		vert2 = c;
	}
	//����Բ�ı�����
	vert1 = vec3(0, radius, 0) * vrot;
	vert2 = vert1 * vrot;
	for(int i = 1; i < vStepNum / 2 - 1; i++)
	{
		vec3 vertu1 = vert1;
		vec3 vertu2 = vert2;
		if(i < vStepNum / 4)
		{
			for(int j = 0; j < uStepNum; j++)
			{
				vec3 a = vertu1;
				vec3 b = vertu2;
				vec3 c = vertu2 * urot;
				vec3 d = vertu1 * urot;

				glBegin(GL_LINE_LOOP);
				glNormal3fv(normalize(cross(b - a, c - a)));
				glVertex3f(a[0], a[1] + height * 0.5, a[2]);
				glVertex3f(b[0], b[1] + height * 0.5, b[2]);
				glVertex3f(c[0], c[1] + height * 0.5, c[2]);
				glVertex3f(d[0], d[1] + height * 0.5, d[2]);
				glVertex3f(a[0], a[1] + height * 0.5, a[2]);
				glEnd();

				vertu1 = d;
				vertu2 = c;
			}
		}
		else
		{
			for(int j = 0; j < uStepNum; j++)
			{
				vec3 a = vertu1;
				vec3 b = vertu2;
				vec3 c = vertu2 * urot;
				vec3 d = vertu1 * urot;

				glBegin(GL_LINE_LOOP);
				glNormal3fv(normalize(cross(b - a, c - a)));
				glVertex3f(a[0], a[1] - height * 0.5, a[2]);
				glVertex3f(b[0], b[1] - height * 0.5, b[2]);
				glVertex3f(c[0], c[1] - height * 0.5, c[2]);
				glVertex3f(d[0], d[1] - height * 0.5, d[2]);
				glVertex3f(a[0], a[1] - height * 0.5, a[2]);
				glEnd();

				vertu1 = d;
				vertu2 = c;
			}
		}
		vert1 = vert1 * vrot;
		vert2 = vert2 * vrot;
	}
	//�����¶���������
	vert1 = vec3(0, -radius, 0);
	vert2 = vert1 * vrot;
	for(int i = 0; i < uStepNum; i++)
	{
		vec3 a = vert1;
		vec3 c = vert2;
		vec3 b = vert2 * urot;
			
		glBegin(GL_LINE_LOOP);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3f(a[0], a[1] - height * 0.5, a[2]);
		glVertex3f(b[0], b[1] - height * 0.5, b[2]);
		glVertex3f(c[0], c[1] - height * 0.5, c[2]);
		glVertex3f(a[0], a[1] - height * 0.5, a[2]);
		glEnd();

		vert2 = b;
	}
	//����Բ��
	vert1 = vec3(radius, -height * 0.5, 0);
	vert2 = vert1 * urot;
	for(int j = 0; j < uStepNum; j++)
	{
		vec3 a = vert1 * urot;
		vec3 b = vert2 * urot;
		vec3 c = b + vec3(0, height, 0);
		vec3 d = a + vec3(0, height, 0);
		glBegin(GL_LINE_LOOP);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3fv(a);
		glVertex3fv(b);
		glVertex3fv(c);
		glVertex3fv(d);
		glVertex3fv(a);
		glEnd();

		vert1 = a;
		vert2 = b;
	}
}
void static inline DrawPhere(float radius)
{
	int uStepNum = 16;
	int vStepNum = 16;
	float ustep = 1 / (float)uStepNum;
	float vstep = 1 / (float)vStepNum;

	mat3 urot = rotateY(ustep * PIx2);
	mat3 vrot = rotateX(vstep * PIx2);
		
	vec3 vert1;
	vec3 vert2;
	//�����϶���������
	vert1 = vec3(0, radius, 0);
	vert2 = vert1 * vrot;
	for(int i = 0; i < uStepNum; i++)
	{
		vec3 a = vert1;
		vec3 b = vert2;
		vec3 c = vert2 * urot;
			
		glBegin(GL_TRIANGLES);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3fv(a);
		glVertex3fv(b);
		glVertex3fv(c);
		glEnd();

		vert2 = c;
	}
	//����Բ�ı�����
	vert1 = vec3(0, radius, 0) * vrot;
	vert2 = vert1 * vrot;
	for(int i = 1; i < vStepNum / 2 - 1; i++)
	{
		vec3 vertu1 = vert1;
		vec3 vertu2 = vert2;

		for(int j = 0; j < uStepNum; j++)
		{
			vec3 a = vertu1;
			vec3 b = vertu2;
			vec3 c = vertu2 * urot;
			vec3 d = vertu1 * urot;

			glBegin(GL_QUADS);
			glNormal3fv(normalize(cross(b - a, c - a)));
			glVertex3fv(a);
			glVertex3fv(b);
			glVertex3fv(c);
			glVertex3fv(d);
			glEnd();

			vertu1 = d;
			vertu2 = c;
		}
			
		vert1 = vert1 * vrot;
		vert2 = vert2 * vrot;
	}
	//�����¶���������
	vert1 = vec3(0, -radius, 0);
	vert2 = vert1 * vrot;
	for(int i = 0; i < uStepNum; i++)
	{
		vec3 a = vert1;
		vec3 c = vert2;
		vec3 b = vert2 * urot;
			
		glBegin(GL_TRIANGLES);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3fv(a);
		glVertex3fv(b);
		glVertex3fv(c);
		glEnd();

		vert2 = b;
	}
}
void static inline DrawPhereWire(float radius)
{
	int uStepNum = 16;
	int vStepNum = 16;
	float ustep = 1 / (float)uStepNum;
	float vstep = 1 / (float)vStepNum;

	mat3 urot = rotateY(ustep * PIx2);
	mat3 vrot = rotateX(vstep * PIx2);
		
	vec3 vert1;
	vec3 vert2;
	//�����϶���������
	vert1 = vec3(0, radius, 0);
	vert2 = vert1 * vrot;
	for(int i = 0; i < uStepNum; i++)
	{
		vec3 a = vert1;
		vec3 b = vert2;
		vec3 c = vert2 * urot;
			
		glBegin(GL_LINE_LOOP);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3fv(a);
		glVertex3fv(b);
		glVertex3fv(c);
		glVertex3fv(a);
		glEnd();

		vert2 = c;
	}
	//����Բ�ı�����
	vert1 = vec3(0, radius, 0) * vrot;
	vert2 = vert1 * vrot;
	for(int i = 1; i < vStepNum / 2 - 1; i++)
	{
		vec3 vertu1 = vert1;
		vec3 vertu2 = vert2;

		for(int j = 0; j < uStepNum; j++)
		{
			vec3 a = vertu1;
			vec3 b = vertu2;
			vec3 c = vertu2 * urot;
			vec3 d = vertu1 * urot;

			glBegin(GL_LINE_LOOP);
			glNormal3fv(normalize(cross(b - a, c - a)));
			glVertex3fv(a);
			glVertex3fv(b);
			glVertex3fv(c);
			glVertex3fv(d);
			glVertex3fv(a);
			glEnd();

			vertu1 = d;
			vertu2 = c;
		}
			
		vert1 = vert1 * vrot;
		vert2 = vert2 * vrot;
	}
	//�����¶���������
	vert1 = vec3(0, -radius, 0);
	vert2 = vert1 * vrot;
	for(int i = 0; i < uStepNum; i++)
	{
		vec3 a = vert1;
		vec3 c = vert2;
		vec3 b = vert2 * urot;
			
		glBegin(GL_TRIANGLES);
		glNormal3fv(normalize(cross(b - a, c - a)));
		glVertex3fv(a);
		glVertex3fv(b);
		glVertex3fv(c);
		glEnd();

		vert2 = b;
	}
};
void static inline DrawQuadY(vec2 halfSize, mat4 m)
{
	glPushMatrix();
	glMultMatrixf(m);

	glBegin(GL_TRIANGLES);
	glVertex3f(-halfSize[0], 0, halfSize[1]);
	glVertex3f( halfSize[0], 0, halfSize[1]);//��������ϵ ˳ʱ��
	glVertex3f( halfSize[0], 0,-halfSize[1]);

	glVertex3f(-halfSize[0], 0, halfSize[1]);
	glVertex3f( halfSize[0], 0,-halfSize[1]);
	glVertex3f(-halfSize[0], 0,-halfSize[1]);
	glEnd();

	glPopMatrix();
	glColor4f(1, 1, 1, 1);
}


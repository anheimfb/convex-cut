#include "_mylib.h"

class demo_convexcut
{

public:	

	void Run()
	{
		Window::Create(-1, -1, 640, 480);

		CTrackball trackball;
		CCamera camera;
		CMeshCutable mesh;
		CMeshCutable meshA;
		CMeshCutable meshB;
		mat3 plane_rot = mat3One;
		vec3 plane_normal = vec3Y;
		float plane_offset = 0;

		mesh.SetAsBox(vec3One);
		while (!Window::GetClose())
		{
			int ww, wh;
			Window::GetSize(ww, wh);
			if(ww < 1 || wh < 1)continue;

			Window::LoopBegin();
			//===========================================================
			glClearDepth(1.0f);//������Ȼ���
			glClearColor(0.9f, 0.95f, 1.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);	
			//===================================================================
			camera.ControlView();
			camera.SetViewport(0, 0, ww, wh);
			camera.SetProjSize(ww, wh);
			camera.SetProjPerspective();
			camera.Perform();
			glLightfv(GL_LIGHT0, GL_POSITION, ToVec4(camera.m_position, 1));
			//����===================================================================
			trackball.Control(&camera, plane_rot);
			plane_normal = vec3(0, 1, 0) * plane_rot;
			plane_offset = 0;
			DrawBox(vec3(2, 0.01, 2), ToMat4(plane_rot, vec3Zero));
			meshA.Clear();
			meshB.Clear();
			mesh.Cut(&meshA, &meshB, plane_normal, plane_offset);
			mesh.Debug(translate(0, 0, 0));
			meshA.Debug(translate(4, 1, 0));
			meshB.Debug(translate(4, -1, 0));
			//===========================================================
			glDisable(GL_CULL_FACE);
			glDisable(GL_LIGHTING);
			camera.PerformGui();
			DebugStrings(camera.GetView(), camera.GetProj(), camera.m_vw, camera.m_vh);			
			//===========================================================
			Window::LoopEnd();
		}

		Window::Destroy();
	}
	CCamera camera;
};
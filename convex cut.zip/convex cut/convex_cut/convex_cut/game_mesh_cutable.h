class CMeshCutable
{
public:
	//for build
	struct Face
	{
		vector<int> v;//��Ⱦʱ��ת�������,��Ϊ��Ҫ����shape
	};
	//for cut
	struct VertMark
	{
		float d;
		int indexA;
		int indexB;
		vec3 v;
	};
	struct VertCut
	{
		int i1;
		int i2;
		int indexA;
		int indexB;
		vec3 v;
	};
	bool HasVertCut(int& indexA, int& indexB, int i1, int i2, list<VertCut>& verts_cut)
	{
		//�᲻����������ڱߺ͸ñ߶����е����,ʵ�ڲ����ټӸ�edge�����?
		//if(verts_mark[i1].cut == true && verts_mark[i2].cut == true)
		//{
		//	return false;
		//}
		//verts_mark[i1].cut = true;
		//verts_mark[i2].cut = true;

		for(auto it = verts_cut.begin(); it != verts_cut.end(); it++)
		{
			VertCut v = *it;
			if((v.i1 == i1 && v.i2 == i2) || (v.i1 == i2 && v.i2 == i1))//�ظ��ĵ�˳��Ӧ�����෴��, ���ǿ��ǿ��ܻ���˳����������
			{
				indexA = v.indexA;
				indexB = v.indexB;
				return true;
			}
		}

		return false;
	}
	void AddVertCut(int indexA, int indexB, int i1, int i2, vec3 vert, vec3 normal, list<VertCut>& verts_cut)
	{
		VertCut vc;
		vc.i1 = i1;
		vc.i2 = i2;
		vc.indexA = indexA;
		vc.indexB = indexB;
		vc.v = vert;

		if(verts_cut.size() < 2)
		{
			verts_cut.push_back(vc);
		}
		else
		{
			//�Ľ�, edgenormal���Ա��浽vertcut��,��ʡ����
			bool mid = false;
			for(auto it = verts_cut.begin(); it != verts_cut.end(); it++)
			{
				auto itn = std::next(it) == verts_cut.end() ? verts_cut.begin() : std::next(it);
				VertCut v1 = *it;
				VertCut v2 = *itn;
				vec3 edge_normal = cross(v2.v - v1.v, -normal);
				float d = dot(edge_normal, vc.v - v1.v);
				if(d > 0)//�ڱ߷����ϵĵ�����м�
				{
					verts_cut.insert(++it, vc);
					mid = true;
					break;
				}
			}

			assert(mid == true);//��Ӧ�ó��ֱ���һȦҲû�в����µ�����
		}
	}
	bool Cut(CMeshCutable* meshA, CMeshCutable* meshB, vec3 normal, float offset)
	{
		vector<VertMark> verts_mark(m_verts.size());
		for(int v = 0; v < m_verts.size(); v++)
		{
			float d = dot(m_verts[v], normal) - offset;

			verts_mark[v].v = m_verts[v];
			verts_mark[v].d = d;
			
			if(d > 0)
			{
				verts_mark[v].indexA = meshA->m_verts.size();
				verts_mark[v].indexB = -1;
				meshA->m_verts.push_back(m_verts[v]);
			}
			else if(d < 0)
			{
				verts_mark[v].indexA = -1;
				verts_mark[v].indexB = meshB->m_verts.size();
				meshB->m_verts.push_back(m_verts[v]);
			}
			else if(d == 0)
			{
				verts_mark[v].indexA = meshA->m_verts.size();
				verts_mark[v].indexB = meshB->m_verts.size();
				meshA->m_verts.push_back(m_verts[v]);
				meshB->m_verts.push_back(m_verts[v]);
			}
		}

		if(meshA->m_verts.size() == 0 || meshB->m_verts.size() == 0)
		{
			return false;
		}

		//����������new meshA new meshB, �����meshA->m_verts meshB->m_verts

		list<VertCut> verts_cut;
		for(int f = 0; f < m_faces.size(); f++)
		{
			Face faceA;  
			Face faceB;
			for(int v = 0; v < m_faces[f].v.size(); v++)
			{
				int v1 = v;
				int v2 = v == m_faces[f].v.size() - 1 ? 0 : v + 1;
				int i1 = GetIndexFV(f, v1);
				int i2 = GetIndexFV(f, v2);
				float d1 = verts_mark[i1].d;
				float d2 = verts_mark[i2].d;
				vec3 vert1 = verts_mark[i1].v;
				vec3 vert2 = verts_mark[i2].v;
				//up---------------------------------
				if(d1 < 0 && d2 > 0)
				{
					vec3 vert = vert1 + (vert2 - vert1) * d1 / (d1 - d2);
					
					int indexA = meshA->m_verts.size();
					int indexB = meshB->m_verts.size();
					if(!HasVertCut(indexA, indexB, i1, i2, verts_cut))
					{
						AddVertCut(indexA, indexB, i1, i2, vert, normal, verts_cut);
						meshA->m_verts.push_back(vert);
						meshB->m_verts.push_back(vert);
					}
					faceB.v.push_back(indexB);
					faceA.v.push_back(indexA);
					faceA.v.push_back(verts_mark[i2].indexA);
				}
				if(d1 == 0 && d2 > 0)
				{
					int indexA = verts_mark[i1].indexA;
					int indexB = verts_mark[i1].indexB;
					if(!HasVertCut(indexA, indexB, i1, i1, verts_cut))
					{
						AddVertCut(indexA, indexB, i1, i1, vert1, normal, verts_cut);
						meshA->m_verts.push_back(vert1);
						meshB->m_verts.push_back(vert1);
					}
					faceA.v.push_back(indexA);
					faceA.v.push_back(verts_mark[i2].indexA);
				}
				if(d1 > 0 && d2 == 0)
				{
					faceA.v.push_back(verts_mark[i2].indexA);
				}
				else if(d1 > 0 && d2 > 0)
				{
					faceA.v.push_back(verts_mark[i2].indexA);
				}
				//down---------------------------------
				else if(d1 > 0 && d2 < 0)
				{
					vec3 vert = vert1 + (vert2 - vert1) * d1 / (d1 - d2);

					int indexA = meshA->m_verts.size();
					int indexB = meshB->m_verts.size();
					if(!HasVertCut(indexA, indexB, i1, i2, verts_cut))
					{
						AddVertCut(indexA, indexB, i1, i2, vert, normal, verts_cut);
						meshA->m_verts.push_back(vert);
						meshB->m_verts.push_back(vert);
					}
					faceA.v.push_back(indexA);
					faceB.v.push_back(indexB);
					faceB.v.push_back(verts_mark[i2].indexB);
				}
				if(d1 == 0 && d2 < 0)
				{
					int indexA = verts_mark[i1].indexA;
					int indexB = verts_mark[i1].indexB;
					if(!HasVertCut(indexA, indexB, i1, i1, verts_cut))
					{
						AddVertCut(indexA, indexB, i1, i1, vert1, normal, verts_cut);
						meshA->m_verts.push_back(vert1);
						meshB->m_verts.push_back(vert1);
					}
					faceB.v.push_back(indexB);
					faceB.v.push_back(verts_mark[i2].indexB);
				}
				if(d1 < 0 && d2 == 0)
				{
					faceB.v.push_back(verts_mark[i2].indexB);
				}
				else if(d1 < 0 && d2 < 0)
				{
					faceB.v.push_back(verts_mark[i2].indexB);
				}
				//middle---------------------------------
				//else if(d1 == 0 && d2 == 0)//���ù�, ֮ǰ����0�������������
				//{
				//	int indexA1 = verts_mark[i1].indexA;
				//	int indexB1 = verts_mark[i1].indexB;
				//	int indexA2 = verts_mark[i2].indexA;
				//	int indexB2 = verts_mark[i2].indexB;
				//	if(!HasVertCut(indexA1, indexB1, i1, i1, verts_cut))
				//	{
				//		AddVertCut(indexA1, indexB1, i1, i1, vert1, normal, verts_cut);
				//		meshA->m_verts.push_back(vert1);
				//		meshB->m_verts.push_back(vert1);
				//	}
				//	if(!HasVertCut(indexA2, indexB2, i2, i2, verts_cut))
				//	{
				//		AddVertCut(indexA2, indexB2, i2, i2, vert2, normal, verts_cut);
				//		meshA->m_verts.push_back(vert2);
				//		meshB->m_verts.push_back(vert2);
				//	}
				//}
			}

			if(faceA.v.size())
			{
				meshA->m_faces.push_back(faceA);
			}
			if(faceB.v.size())
			{
				meshB->m_faces.push_back(faceB);
			}
		}

		//�����и���
		Face faceA;  
		Face faceB;
		faceA.v.resize(verts_cut.size());
		faceB.v.resize(verts_cut.size());
		int iA = 0;
		int iB = verts_cut.size() - 1;
		for(auto it = verts_cut.begin(); it != verts_cut.end(); it++)
		{
			faceA.v[iA] = (*it).indexA;
			faceB.v[iB] = (*it).indexB;
			iA++;
			iB--;
		}
		meshA->m_faces.push_back(faceA);//����Ӧ����push_back, ����Ḵ���ڴ�
		meshB->m_faces.push_back(faceB);

		return true;
	}

	void	Debug(mat4 tran)
	{
		glPushMatrix();
		glMultMatrixf(tran);
		glColor4f(1.0f,0.7f,0.7f, 1);
		glBegin(GL_TRIANGLES);
		for(int f = 0; f < m_faces.size(); f++)
		{
			vec3 n;
			int i = 0;
			bool hasNormal = true;
			while(!FaceNormal(n, GetFV(f, i), GetFV(f, i + 1), GetFV(f, i + 2)))
			{
				i++;
				if(i + 2 >= m_faces[f].v.size())
				{
					hasNormal = false;
					break;//one bad face means one bad polyhedron, ��������Ҳ�п��ܰѴ�Ĳ���ȥ����, Ӧ���ڷָ�ʱ�ͼ��, �����ָ��
				}
			}
			if(hasNormal)
			{
				glNormal3fv(n);
			}

			for(int v = 1; v + 1 < m_faces[f].v.size(); v += 1)//vector.size���ص����Ϳ�����uint, 0 - 1 ���ܵõ�����
			{
				glVertex3fv(GetFV(f, 0));
				glVertex3fv(GetFV(f, v));
				glVertex3fv(GetFV(f, v + 1));
			}
		}
		glEnd();
		glPopMatrix();
	}
	void	SetAsBox(vec3 halfSize)
	{
		m_verts.resize(8);
		m_faces.resize(6);

		/*
		y   z
		|  /
		| /
		|/___x  ��������ϵ


		   3_________2
		   /        /
		0 /________/1

		   7_________6
		   /        /
		4 /________/5
		
		*/

		m_verts[0] = halfSize * vec3(-1, 1,-1);
		m_verts[1] = halfSize * vec3( 1, 1,-1);
		m_verts[2] = halfSize * vec3( 1, 1, 1);
		m_verts[3] = halfSize * vec3(-1, 1, 1);
		m_verts[4] = halfSize * vec3(-1,-1,-1);
		m_verts[5] = halfSize * vec3( 1,-1,-1);
		m_verts[6] = halfSize * vec3( 1,-1, 1);
		m_verts[7] = halfSize * vec3(-1,-1, 1);		
		
		for(int i = 0; i < m_faces.size(); i++)
		{	
			m_faces[i].v.resize(4);
		}

		m_faces[0].v[0] = 3;
		m_faces[0].v[1] = 2;
		m_faces[0].v[2] = 1;
		m_faces[0].v[3] = 0;

		m_faces[1].v[0] = 4;
		m_faces[1].v[1] = 5;
		m_faces[1].v[2] = 6;
		m_faces[1].v[3] = 7;

		m_faces[2].v[0] = 7;
		m_faces[2].v[1] = 3;
		m_faces[2].v[2] = 0;
		m_faces[2].v[3] = 4;

		m_faces[3].v[0] = 2;
		m_faces[3].v[1] = 6;
		m_faces[3].v[2] = 5;
		m_faces[3].v[3] = 1;

		m_faces[4].v[0] = 7;
		m_faces[4].v[1] = 6;
		m_faces[4].v[2] = 2;
		m_faces[4].v[3] = 3;

		m_faces[5].v[0] = 0;
		m_faces[5].v[1] = 1;
		m_faces[5].v[2] = 5;
		m_faces[5].v[3] = 4;	

	}
	void	Clear()
	{
		m_faces.clear();
		m_verts.clear();
	}
	int		GetIndexFV(int f, int v)
	{
		assert(f >= 0 && f < m_faces.size());
		assert(v >= 0 && v < m_faces[f].v.size());
		return m_faces[f].v[v];
	}
	vec3	GetFV(int f, int v)
	{
		assert(f >= 0 && f < m_faces.size());
		assert(v >= 0 && v < m_faces[f].v.size());
		return m_verts[m_faces[f].v[v]];
	}
	
	vector<Face> m_faces;
	vector<vec3> m_verts;
	//vector<vec2> texcoords;//VertMark,VertCut����һ�±��и������, �Ϳ��Խ���texcoords���и�
};